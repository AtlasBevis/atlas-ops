/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.iceberg.encryption;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.withSettings;

import java.util.Map;
import org.apache.iceberg.io.FileIO;
import org.apache.iceberg.io.FileInfo;
import org.apache.iceberg.io.SupportsPrefixOperations;
import org.junit.jupiter.api.Test;

public class TestEncryptingFileIO {

  @Test
  public void delegateEncryptingIOWithAndWithoutMixins() {
    EncryptionManager em = mock(EncryptionManager.class);

    FileIO fileIONoMixins = mock(FileIO.class);
    assertThat(EncryptingFileIO.combine(fileIONoMixins, em))
        .isInstanceOf(EncryptingFileIO.class)
        .extracting(EncryptingFileIO::encryptionManager)
        .isEqualTo(em);

    FileIO fileIOWithMixins =
        mock(FileIO.class, withSettings().extraInterfaces(SupportsPrefixOperations.class));
    assertThat(EncryptingFileIO.combine(fileIOWithMixins, em))
        .isInstanceOf(EncryptingFileIO.WithSupportsPrefixOperations.class)
        .extracting(EncryptingFileIO::encryptionManager)
        .isEqualTo(em);
  }

  @Test
  public void prefixOperationsDelegation() {
    EncryptionManager em = mock(EncryptionManager.class);
    SupportsPrefixOperations delegate = mock(SupportsPrefixOperations.class);

    EncryptingFileIO.WithSupportsPrefixOperations fileIO =
        (EncryptingFileIO.WithSupportsPrefixOperations) EncryptingFileIO.combine(delegate, em);

    String prefix = "prefix";
    Iterable<FileInfo> fileInfos = mock(Iterable.class);
    when(delegate.listPrefix(prefix)).thenReturn(fileInfos);
    assertThat(fileIO.listPrefix(prefix)).isEqualTo(fileInfos);

    fileIO.deletePrefix(prefix);
    verify(delegate).deletePrefix(prefix);
  }

  @Test
  public void properties() {
    EncryptionManager em = mock(EncryptionManager.class);
    FileIO io = mock(FileIO.class);
    when(io.properties()).thenReturn(Map.of("key", "value"));

    assertThat(EncryptingFileIO.combine(io, em).properties())
        .containsExactly(Map.entry("key", "value"));
  }
}
